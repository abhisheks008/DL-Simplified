# Link for the dataset

https://www.kaggle.com/fedesoriano/stroke-prediction-dataset
